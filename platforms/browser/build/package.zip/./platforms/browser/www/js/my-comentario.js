$$(document).on('click','#btn-comentario',function(){
   comentario_cargar();     
});

function comentario_cargar(){
     mainView.router.load({
      template: myApp.templates.comentario,
      animatePages: false,
      // context: {carpetas: info,cursos:info_curso},
      reload: true, 
    }); 


      $$('.page[data-page="comentario"] #descripcion').keydown(function(event){
        if ( event.which == 13 ) {
          v_comentario=$$(this).val();
          $$(this).val('');
          vconsole(v_comentario);
          var data=script({opcion:"comentario_nuevo", usuario:Gusuario_id,comentario:v_comentario},1);
          console.log(data);

        }

      });

      set
     
}