$$(document).on('click','#btn-curso',function(){
// Global
var id_curs;
var id_rol;


var datos = {
	opcion:"curso_listado",
	usuario:Gusuario_id}; 

	myApp.showIndicator();
	script(datos);
});

function modulo_curso(datos){
	mainView.router.load({
      	template: myApp.templates.curso,
      	animatePages: true,
      	context: datos,
      	reload: true, 
    	});  
}

$$(document).on('click','.cursos .curso .icono',function(){
	$$('.cursos .curso .temporal').remove();
	$$(this).parents('.cursos').find('.curso').removeClass('activo');
});

$$(document).on('click','.cursos .curso > table',function(){
	id_curs=$$(this).attr('id_curs');
	id_rol=$$(this).parents('.curso').attr('rol');
	$$('.cursos').find('.curso').removeClass('activo');
	$$(this).parents('.curso').addClass('activo');
	$$('.cursos .curso .temporal').remove();
	$$(this).parents('.curso').find('.icono').append('<div class="temporal" style="font-size:20px;position:absolute;margin-top:-55px;margin-left:55px;color:white">'+
										$$(this).parents('.curso').find('.titulo').html()+
										'</div>');

	$$(this).parents('.curso').append(	'<div class="temporal animated fadeIn" style="background-color:#424242;padding:10px;margin-top:40px; margin-left:-10px;width:100%;color:white">'+
								'<span class="icon-user" style="color:white;margin-right:20px"></span> '+
								$$(this).parents('.curso').find('.cat').html()+
							'</div>');
	$$(this).parents('.curso').append('<div class="temporal cur_contenido"></div>');

	// cargando datos
	vconsole(id_curs);
	if (localStorage.cursos){
		var info=JSON.parse(localStorage.cursos);
		for (vinfo in info){
			if (info[vinfo].id_curs==id_curs){
				var curso_descripcion=info[vinfo].curso_descripcion;
				var conteo_tema=info[vinfo].conteo_tema;
				var conteo_tarea=info[vinfo].conteo_tarea;
				// var curso_descripcion=info[vinfo].curso_descripcion;
			}
		}

	}   

	var compiledTemplate = Template7.compile($$('#curso_info').html());
	var context = {
	    curso:{'contenido':pad(curso_descripcion,1),
			'temas':pad(conteo_tema,2),
			'tareas':pad(conteo_tarea,2),
			'archivos':pad(0,2)} ,
	};
	$$('.cur_contenido').html(compiledTemplate(context));

});

$$(document).on('click','.cur_contenido',function(){
	// vconsole(1);
    	myApp.showPreloader();
      mainView.router.load({
        template: myApp.templates.curso_detalle,
      });
      myApp.hidePreloader();

});

$$(document).on('click','.cursos-detalle .opcion',function(){
	$$('.cursos-detalle .opcion').removeClass('activo');
	$$(this).addClass('activo');
	opcion=$$(this).attr('opcion');
	if (opcion==1){
		modulo_curso_cronograma();
	}
	if (opcion==2){
		$$('.cursos.detalle .contenido').html('');
	}
	if (opcion==3){
		modulo_curso_tareas();
	}
})


function modulo_curso_cronograma(){
	var compiledTemplate = Template7.compile($$('#curso_detalle_lineatiempo').html());
	var context_curso = {"elementos":[
					{"mes":"DIC","dia":"25","datos":[ 
						{"tarea":"1","titulo":"titulo del elemento","descripcion":"Prueba de tarea"},
						{"tarea":"1","titulo":"titulo del elemento","descripcion":"Prueba de tarea2"}]
					},
					{"mes":"DIC","dia":"26","datos":[ 
						{"tarea":"","titulo":"titulo del elemento","descripcion":"tema"},
						{"tarea":"1","titulo":"titulo del elemento","descripcion":"Prueba de tarea2"}]
					},
					{"mes":"DIC","dia":"25","datos":[ 
						{"tarea":"1","titulo":"titulo del elemento","descripcion":"Prueba de tarea"},
						{"tarea":"1","titulo":"titulo del elemento","descripcion":"Prueba de tarea2"}]
					},
					{"mes":"DIC","dia":"26","datos":[ 
						{"tarea":"","titulo":"titulo del elemento","descripcion":"tema"},
						{"tarea":"1","titulo":"titulo del elemento","descripcion":"Prueba de tarea2"}]
					},
					{"mes":"DIC","dia":"25","datos":[ 
						{"tarea":"1","titulo":"titulo del elemento","descripcion":"Prueba de tarea"},
						{"tarea":"1","titulo":"titulo del elemento","descripcion":"Prueba de tarea2"}]
					},
					{"mes":"DIC","dia":"26","datos":[ 
						{"tarea":"","titulo":"titulo del elemento","descripcion":"tema"},
						{"tarea":"1","titulo":"titulo del elemento","descripcion":"Prueba de tarea2"}]
					}
				]};
	
	// vconsole(context_curso);
	
	$$('.cursos.detalle .contenido').html(compiledTemplate(context_curso));
	
}

function modulo_curso_tareas(){
	$$('#curso_detalle_tareas_seleccion1').off('click');
	$$('#curso_detalle_tareas_seleccion2').off('click');
	// alert(1);
	if (id_rol==2){
		var compiledTemplate = Template7.compile($$('#curso_detalle_tareas_menu').html());
		$$('.cursos.detalle .contenido').html(compiledTemplate());


		$$('#curso_detalle_tareas_seleccion1').on('click',function(){
			modulo_curso_tareas_nuevo();	
		});	
		$$('#curso_detalle_tareas_seleccion2').on('click',function(){
			modulo_curso_tareas_listado();	
		});	
	}else{
		modulo_curso_tareas_listado();	
	}
}
function modulo_curso_tareas_listado(){
	var datos = {
	opcion:"curso_listado_tareas",
	curso:id_curs}; 
	myApp.showIndicator();

	script(datos);
	
	myApp.hideIndicator();

	
}
function modulo_curso_tareas_nuevo(){
	$$('.curso_detalle_tareas_2_guardar').off('click');

	var compiledTemplate = Template7.compile($$('#curso_detalle_tareas_2').html());
	$$('.cursos.detalle .contenido').html(compiledTemplate());

	var monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto' , 'Septiembre' , 'Octubre', 'Noviembre', 'Diciembre'];
	var dayNames =  ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado'];
	var dayNamesShort1=['Dom','Lun','Mar','Mie','Jue','Vie','Sab'];

	var calendarInline = myApp.calendar({
	    container: '#curso_detalle_tareas_2_calendario',
	    value: [new Date()],
	    weekHeader: true,
	     dateFormat: 'dd/MM/yyyy',
	    dayNamesShort:dayNamesShort1,
	    toolbarTemplate: 
	        '<div class="toolbar calendar-custom-toolbar">' +
	            '<div class="toolbar-inner" style="background-color:#2196F3;color:white">' +
	                '<div class="left">' +
	                    '<a href="#" class="link icon-only"><i class="icon icon-back"></i></a>' +
	                '</div>' +
	                '<div class="center"></div>' +
	                '<div class="right">' +
	                    '<a href="#" class="link icon-only"><i class="icon icon-forward"></i></a>' +
	                '</div>' +
	            '</div>' +
	        '</div>',
	    onOpen: function (p) {
	        $$('.calendar-custom-toolbar .center').text(monthNames[p.currentMonth] +', ' + p.currentYear);
	        $$('.calendar-custom-toolbar .left .link').on('click', function () {
	            calendarInline.prevMonth();
	        });
	        $$('.calendar-custom-toolbar .right .link').on('click', function () {
	            calendarInline.nextMonth();
	        });
	    },
	    onMonthYearChangeStart: function (p) {
	        $$('.calendar-custom-toolbar .center').text(monthNames[p.currentMonth] +', ' + p.currentYear);
	    }
	}); 


	$$('.curso_detalle_tareas_2_guardar').click(function(){
		var vtarea=$$('#curso_detalle_tareas_2_titulo').val();
		var vdescripcion=$$('#curso_detalle_tareas_2_descripcion').val();
		var vfecha= new Date(calendarInline.value);

		var vfecha=vfecha.getFullYear() +"-"+(vfecha.getMonth() + 1) + '-' + vfecha.getDate() + '- 00:00:00' ;

		alert(vfecha);
		var datos = {
		opcion:"curso_tarea_nuevo",
		tarea:vtarea,
		curso:id_curs,
		descripcion:vdescripcion,
		fecha_finalizacion:vfecha,
		usuario:Gusuario_id}; 

		myApp.showIndicator();
		vconsole(script(datos,1));
		myApp.hideIndicator();


		var compiledTemplate = Template7.compile($$('#curso_detalle_tareas_menu').html());
		$$('.cursos.detalle .contenido').html(compiledTemplate());

	});



	
}

