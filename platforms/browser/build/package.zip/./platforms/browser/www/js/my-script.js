function script(datos,devolver){
  // devolver es opcional null = no ; 1 = si 
vconsole('>INICIANDO SCRIPT<');
v_async=true;
var glob_resp;
if (devolver){ v_async=false; vconsole('EN ESPERA');}

  $$.ajax({
    dataType: 'jsonp',
    data: datos,
    jsonp: "callback", 
    async:v_async,
    processData: true,
    url: 'https://zaionnet.000webhostapp.com/funcion.php',
    method:'POST',
    success: function searchSuccess(resp) {
      // alert(resp);
      vconsole('>>>>>'+resp);
      glob_resp=resp;
    	if ((resp!='' && !devolver) || (resp!='' && devolver==2)  ){
        // vconsole((resp);
	    	resp2=JSON.parse(resp);
	    	var info=[];
        
          // vconsole((info);
        // ====================================================================================================
        if (datos.opcion=='curso_listado'){
          for (v_resp in resp2){info.push(JSON.parse(resp2[v_resp]));}
  		    localStorage.setItem('cursos', JSON.stringify(info));
        }
        if (datos.opcion=='curso_listado_tareas'){
          for (v_resp in resp2){info.push(JSON.parse(resp2[v_resp]));}
          localStorage.setItem('cursos_tareas', JSON.stringify(info));
        }
        // ====================================================================================================
         // myApp.hideIndicator();
	   }
     // si no existen valore
      if (datos.opcion=='curso_listado'){
    	  if (localStorage.cursos){modulo_curso({"cursos":JSON.parse(localStorage.cursos) });}else{modulo_curso('');}    	
          myApp.hideIndicator();
      }
      if (datos.opcion=='curso_listado_tareas'){
        if (localStorage.cursos_tareas){     
          var compiledTemplate = Template7.compile($$('#curso_detalle_tareas_1').html());
          $$('.cursos.detalle .contenido').html(compiledTemplate({"datos":JSON.parse(localStorage.cursos_tareas) }));
        }
        myApp.hideIndicator();
      }
    },
    error: function searchError(xhr, err) {
     	myApp.hideIndicator();
      myApp.alert('Ha ocurrido un error', 'Cursos');
      console.error("Error on ajax call: " + err);
      vconsole(JSON.stringify(xhr));
      if (devolver){
          return err;
        }

        // ====================================================================================================
        if (datos.opcion=='curso_listado'){
          if (localStorage.cursos){modulo_curso({"cursos":JSON.parse(localStorage.cursos) });}else{modulo_curso('');} 
        }

        if (datos.opcion=='curso_listado_tareas'){
          if (localStorage.cursos_tareas){     
            var compiledTemplate = Template7.compile($$('#curso_detalle_tareas_1').html());
            $$('.cursos.detalle .contenido').html(compiledTemplate({"datos":JSON.parse(localStorage.cursos_tareas) }));
          }
          myApp.hideIndicator();
        }
        // ====================================================================================================
    }
  });
  vconsole('>FINALIZANDO SCRIPT<');
          if (devolver){
          vconsole(glob_resp);
          try{
            return JSON.parse(glob_resp);
          }catch(e){
            return glob_resp;
          }
        }
        glob_resp='';

}